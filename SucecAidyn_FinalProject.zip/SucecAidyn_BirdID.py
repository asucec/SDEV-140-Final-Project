"""
PROGRAM: Indiana Bird Identificaiton
NAME: Aidyn Sucec
CREATION DATE: 11/28/22
FINAL VERSION DATE: 
PURPOSE: The goal of this program is to help a user identify common birds in Indiana. It takes the user 
through a series of 3 questions describing the bird's size, type, color, and location. It then uses this 
information to identify the bird.
"""
#imports
from breezypythongui import EasyFrame
from tkinter.font import Font
from tkinter import PhotoImage

#BirdID class - main window
class BirdID(EasyFrame):
  
  def __init__(self):
    EasyFrame.__init__(self, title="Indiana Bird Identification")
    
    #window attributes
    self.setSize(width=475, height=400)
    self.setResizable(True)
    self.backgrnd="#B6E6C8"
    self.setBackground(self.backgrnd)
    
    #fonts
    self.headerFont=Font(family="Corbel", size=28)
    self.labelFont=Font(family="Corbel", size=16)

    #start screen w/ instructions
    self.prompt=self.addLabel(text="Answer the questions to start \n identifying your bird.", 
    row=0, column=0, columnspan=2, sticky="NSEW", font=self.headerFont, background=self.backgrnd)
    self.addButton(text="   START   ", row=1, column=0, columnspan=2, command=self.start)
    
    #ID bird variables
    self.crow = {
    "name":"American Crow",
    "size":"large",
    "type":"perching",
    "color":["black"]}
    self.blueJay = {
    "name":"Blue Jay",
    "size":"medium",
    "type":"perching",
    "color":["black", "gray", "white", "blue"]}
    self.downyWp = {
    "name":"Downy Woodpecker",
    "size":"small",
    "type":"tree-clinging",
    "color":["black", "white", "red"]}
    self.houseSp = {
    "name":"House Sparrow",
    "size":"small",
    "type":"perching",
    "color":["brown", "black", "gray", "white"]}
    self.mallard = {
    "name":"Mallard",
    "size":"large",
    "type":"duck-like",
    "color":["brown", "black", "gray", "white", "green", "blue"]}
    self.cardinal = {
    "name":"Northern Cardinal",
    "size":"medium",
    "type":"perching",
    "color":["brown", "black", "gray", "red"]}
    self.rockPigeon = {
    "name":"Rock Pigeon",
    "size":"medium",
    "type":"pigeon-like",
    "color":["brown", "black", "gray", "white", "green", "blue", "purple"]}

    #list of ID bird variables
    self.idBirds = [self.crow, self.blueJay, self.downyWp, self.houseSp, self.mallard, self.cardinal, self.rockPigeon]
    self.setBirds()
  
  def setBirds(self):
    """
    Initiates userBird dictionary with keys and empty values.
    Sets finalBird to none. Used in the restart method.
    """
    #dictionary to hold attributes of user's bird
    self.userBird = {
      "size":"",
      "type":"",
      "color":[]
    }
    #identity of user bird (either in idBirds list or None)
    self.finalBird = None
  
  #navigation methods
  
  def buttonPanel(self):
    """
    Adds a panel with the next and back 
    buttons to the bottom of the window.
    """
    self.btnPanel=self.addPanel(row=5, column=0, columnspan=3, background=self.backgrnd)
    self.nextBtn=self.btnPanel.addButton(text="Next", row=5, column=2, command=self.next)
    self.backBtn=self.btnPanel.addButton(text="Back", row=5, column=0, command=self.back)
  
  def start(self):
    """
    Destroys the label from the start method, 
    advances to question 1, adds a panel containing 
    'next' and 'back' buttons used for navigation.
    """
    self.setSize(width=475, height=400)
    self.qNum=1 #counter for the question user is on - used in next and back functions
    self.question1()
    self.prompt.destroy()
    self.buttonPanel()

  def next(self):
    """
    Allows the user to advance to the next question.
    """
    self.qNum+=1
    if self.qNum <= 1:
      self.question1()
    elif self.qNum == 2:
      self.question2()
    elif self.qNum == 3:
      self.question3()
    elif self.qNum == 4:
      self.idScreen()
    else:
      self.messageBox(title="ERROR", message="Question number out of range") #debugging
  
  def back(self):
    """
    Allows the user to return to the previous question.
    """
    self.qNum-=1
    if self.qNum <= 1:
      self.qNum = 1 #prevents count from going into negatives if user clicks back from q1
      self.question1()
    elif self.qNum == 2:
      self.question2()
    elif self.qNum == 3:
      self.question3()
    elif self.qNum == 4:
      self.idScreen()
    else:
      self.messageBox(title="ERROR", message="Question number out of range") #debugging

  def restart(self):
    """
    Resets the application and allows the 
    user to answer the questions again.
    """
    try: self.imageLabel.destroy()
    except: None #if image label has already been destroyed, no error message
    self.setSize(width=475, height=400)
    self.setBirds()
    self.buttonPanel()
    self.question1()
    self.qNum = 1
  
  def exit(self):
    """
    Ends the program.
    """
    self.quit()
  
  #question methods
  
  def question1(self):
    """
    Prompts user to select bird size. User answers by 
    choosing 1 of the 3 buttons in the radio button group.
    """
    self.label=self.addLabel(text="What size was the bird? Choose one.", 
      row=0, column=0, sticky="NSEW", 
      font=self.labelFont, background=self.backgrnd)
    self.answer=self.addRadiobuttonGroup(row=1, column=0)
    self.answer.addRadiobutton("Small (sparrow-sized)", command=self.sizeSmall)
    self.answer.addRadiobutton("Medium (robin-sized)", command=self.sizeMed)
    self.answer.addRadiobutton("Large (crow-sized)", command=self.sizeLarge)

  def question2(self):
    """
    Prompts user to select bird type. User answers by 
    choosing 1 of the 4 buttons in the radio button group.
    """
    self.label["text"] = "What type of bird was it? Choose one."
    self.answer=self.addRadiobuttonGroup(row=1, column=0)
    self.answer.addRadiobutton("Duck-like bird", command=self.typeDuck)
    self.answer.addRadiobutton("Perching bird", command=self.typePerch)
    self.answer.addRadiobutton("Pigeon-like bird", command=self.typePigeon)
    self.answer.addRadiobutton("Tree-clinging bird", command=self.typeCling)

  def question3(self):
    """
    Prompts user to select bird color(s). User answers 
    by choosing any of the 10 check buttons.
    """
    self.label["text"] = "What color(s) was the bird? Choose all that apply."
    self.answer=self.addPanel(row=1, column=0, rowspan=3, columnspan=4) #panel to place check btns on
    self.answer.addCheckbutton(text="Brown", row=1, column=0, sticky="NSEW", command=self.checkBrown)
    self.answer.addCheckbutton(text="Black", row=1, column=1, sticky="NSEW", command=self.checkBlack)
    self.answer.addCheckbutton(text="Gray", row=1, column=2, sticky="NSEW", command=self.checkGray)
    self.answer.addCheckbutton(text="White", row=1, column=3, sticky="NSEW", command=self.checkWhite)
    self.answer.addCheckbutton(text="Red", row=2, column=0, sticky="NSEW", command=self.checkRed)
    self.answer.addCheckbutton(text="Orange", row=2, column=1, sticky="NSEW", command=self.checkOrange)
    self.answer.addCheckbutton(text="Yellow", row=2, column=2, sticky="NSEW", command=self.checkYellow)
    self.answer.addCheckbutton(text="Green", row=2, column=3, sticky="NSEW", command=self.checkGreen)
    self.answer.addCheckbutton(text="Blue", row=3, column=0, sticky="NSEW", command=self.checkBlue)
    self.answer.addCheckbutton(text="Purple", row=3, column=1, sticky="NSEW", command=self.checkPurple)
  
  #button commands for quesitons
 
  """
  Q1 COMMANDS -- BIRD SIZE
  The group of size methods updates the userBird
  dictionary to contain the chosen size.
  """
  def sizeSmall(self):
    self.userBird["size"] = "small"
  def sizeMed(self):
    self.userBird["size"] = "medium"
  def sizeLarge(self):
    self.userBird["size"] = "large"
  
  """
  Q2 COMMANDS -- BIRD TYPE
  The group of type methods updates the userBird
  dictionary to contain the chosen type.
  """
  def typeDuck(self):
    self.userBird["type"] = "duck-like"
  def typePerch(self):
    self.userBird["type"] = "perching"
  def typePigeon(self):
    self.userBird["type"] = "pigeon-like"
  def typeCling(self):
    self.userBird["type"] = "tree-clinging"
  
  """
  Q3 COMMANDS -- BIRD COLOR(S)
  The group of color methods append the userBird
  dictionary to contain the chosen color(s).
  """
  def checkBrown(self):
    self.userBird["color"].append("brown")
  def checkBlack(self):
   self.userBird["color"].append("black")
  def checkGray(self):
      self.userBird["color"].append("gray")
  def checkWhite(self):
      self.userBird["color"].append("white")
  def checkRed(self):
      self.userBird["color"].append("red")
  def checkOrange(self):
      self.userBird["color"].append("orange")
  def checkYellow(self):
      self.userBird["color"].append("yellow")
  def checkGreen(self):
      self.userBird["color"].append("green")
  def checkBlue(self):
      self.userBird["color"].append("blue")
  def checkPurple(self):
      self.userBird["color"].append("purple")

  #identification methods
  
  def idScreen(self):
    """
    User is informed that all questions have been completed. 
    Next and back buttons replaced by restart and exit 
    buttons. User is prompted to ID their bird.
    """
    #user can't use next/back btns on last screens -- must exit or restart
    self.btnPanel.destroy()
    self.answer.destroy()
    self.label["text"] = "You've completed \n all the questions!"
    self.label["font"] = self.headerFont
    self.panel = self.addPanel(row=1, column=0, background=self.backgrnd)
    #button prompts user to ID bird, uses identify method
    self.idBtn = self.panel.addButton(text="  ID MY BIRD  ", row=1, column=0, columnspan=2, command=self.identify)
    #buttons allow user to restart or exit the program
    self.panel.addButton(text="Restart", row=2, column=0, command=self.restart)
    self.panel.addButton(text="Exit", row=2, column=1, command=self.exit)
  
  def identify(self):
    """
    Attempts to identify user's bird. First sorts by size, 
    then type, then calls sameColor method. If bird cannot be 
    identified, it's set to None. Calls birdIdentified method.
    """
    #first set of if statements sort by size
    if self.userBird["size"] == "large":
      #second set sorts by type
      if self.userBird["type"] == "duck-like":
        self.idBirds = [self.mallard]
        #calls method to verify colors
        self.sameColor(self.idBirds)
      elif self.userBird["type"] == "perching":
        self.idBirds = [self.crow]
        self.sameColor(self.idBirds)
      else: self.finalBird = None
    
    elif self.userBird["size"] == "medium":
      if self.userBird["type"] == "pigeon-like":
        self.idBirds = [self.rockPigeon]
        self.sameColor(self.idBirds)
      elif self.userBird["type"] == "perching":
        self.idBirds = [self.blueJay, self.cardinal]
        self.sameColor(self.idBirds)
      else: self.finalBird = None
    
    elif self.userBird["size"] == "small":
     if self.userBird["type"] == "tree-clinging":
      self.idBirds = [self.downyWp]
      self.sameColor(self.idBirds)
     elif self.userBird["type"] == "perching":
      self.idBirds = [self.houseSp]
      self.sameColor(self.idBirds)
     else: self.finalBird = None
    
    #works even if finalBird is None
    self.birdIdentified(self.finalBird)
  
  def sameColor(self, idBirds):
    """
    Determines if all of the userBird's colors are contained 
    within the dictionary of the idBird. If so, finalBird 
    is identified. If not, finalBird is set to None.
    """
    for bird in idBirds:
      same = (all([color in bird["color"] for color in self.userBird["color"]]))
      if same == True:
        self.finalBird = bird
        return self.finalBird
      else: self.finalBird = None
  
  def birdIdentified(self, finalBird):
    """
    If the userBird was identified, finds the appropriate 
    image to display. If not, displays a message 
    prompting user to try again.
    """
    #window attributes - window set large enough for images
    self.setSize(width=800, height=600)
    self.idBtn.destroy()

    if finalBird == None:
      self.label["text"] = "Sorry, I couldn't find a bird like that. \n Try again?"
    else:
      self.label["text"] = "Your bird may be a:"
      self.imageLabel = self.panel.addLabel(text="", 
      row=1, column=0, columnspan=2, sticky="NSEW")

      if finalBird["name"] == "American Crow":
        self.image = PhotoImage(file="crow.png")
      elif finalBird["name"] == "Blue Jay":
        self.image = PhotoImage(file="bluejay.png")
      elif finalBird["name"] == "Downy Woodpecker":
        self.image = PhotoImage(file="downywoodpecker.png")
      elif finalBird["name"] == "House Sparrow":
        self.image = PhotoImage(file="housesparrow.png")
      elif finalBird["name"] == "Mallard":
        self.image = PhotoImage(file="mallard.png")
      elif finalBird["name"] == "Northern Cardinal":
        self.image = PhotoImage(file="cardinal.png")
      elif finalBird["name"] == "Rock Pigeon":
        self.image = PhotoImage(file="rockpigeon.png")
      else: self.messageBox(title="Error", message="Sorry, I don't recognize that bird.") #for debugging
      
    try: self.imageLabel["image"] = self.image
    except: self.imageLabel.destroy()
      

def main(): #main method
  BirdID().mainloop() 

if __name__ == "__main__":
  main()